/**
 * Create an AWS Lambda function that converts an integer to a roman numeral
 * @author Andrew Jarombek
 * @since 8/29/2018
 */

exports.handler = (event, context, callback) => {

    const resp = "Hello";

    callback(null, resp);
};